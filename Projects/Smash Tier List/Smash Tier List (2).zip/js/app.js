var damage = document.getElementById("damage");
var recovery = document.getElementById("damage");
var neutral = document.getElementById("damage");
var defense = document.getElementById("damage");
var weight = document.getElementById("damage");

var app = new Vue({
    el: "#app",
    data: {
        page1: true, //true if on home page
        page2: false, //true if on character page
        transition: false, //whether a transition is needed or not
    },
    data() {
        return {
            data: null,
            page1: true, //true if on home page
            page2: false, //true if on character page
            transition: false, //whether a transition is needed or not
            characterId: "";
        }
    },
    methods: {
        goToCharacterPage: function() {
            this.page1 = false;
            this.page2 = true;
            this.transition = true;
            this.characterId = this.id;

            damage.innerHTML = "Damage:  " + {{ data.characters.this.characterId }} + ".stats.damage";
            recovery.innerHTML = "Recovery:  {{ data.characters." + this.characterId + ".stats.recovery }} ";
            neutral.innerHTML = "Neutral:  {{ data.characters." + this.characterId + ".stats.neutral }} ";
            defense.innerHTML = "Defense:  {{ data.characters." + this.characterId + ".stats.defense }} ";
            weight.innerHTML = "Weight:  {{ data.characters." + this.characterId + ".stats.weight }} ";
        },
        goToSnake: function() {
            this.page1 = false;
            this.page2 = true;
            this.transition = true;
        },
        goHome: function() {
            this.page1 = true;
            this.page2 = false;
            this.transition = true;
            
        }, 
        select: function(event) {
            characterId = event.currentTarget.id;
            console.log(characterId);
            this.goToCharacterPage();
        }
        
    },
    mounted() {
        axios
        .get('data/smash.json')
        .then(response => (this.data = response.data))
    }
})