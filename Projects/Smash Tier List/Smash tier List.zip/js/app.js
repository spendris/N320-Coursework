
var app = new Vue({
    el: "#app",
    data: {
        page1: true, //true if on home page
        page2: false, //true if on character page
        transition: false, //whether a transition is needed or not
    },
    data() {
        return {
            data: null,
            page1: true, //true if on home page
            page2: false, //true if on character page
            transition: false, //whether a transition is needed or not
        }
    },
    methods: {
        goToCharacterPage: function() {
            this.page1 = false;
            this.page2 = true;
            this.transition = true;
            
        },
        goToSnake: function() {
            this.page1 = false;
            this.page2 = true;
            this.transition = true;
        },
        goHome: function() {
            this.page1 = true;
            this.page2 = false;
            this.transition = true;
            
        }
    },
    mounted() {
        axios
        .get('data/smash.json')
        .then(response => (this.data = response.data))
    }
})